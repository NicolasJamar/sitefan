A Pen created at CodePen.io. You can find this one at https://codepen.io/agrayson/pen/aLpKB.

 Simple dynamic accordion that can be duplicated as much as you want!